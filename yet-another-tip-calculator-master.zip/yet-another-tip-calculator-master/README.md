# yet-another-tip-calculator

1- Download the repository
2- Use any code editor to edit files.
3- enjoy!!
